public class TollDevice 
{
    private final String name;
    private int counter;

    public TollDevice(String name) 
    {
        this.name=name;
        this.counter=0;
    }

    public int getMoney() 
    {
        return counter;
    }

    public String getName()
     {
        return name;
    }

    public boolean AddMoney(int money) 
    {
        if (money>0) 
        {
            this.counter+=money;
            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean PayToll(int toll) 
    {
        if (toll<=counter) 
        {
            this.counter-=toll;
            return true;
        }
        else
        {
            return false;
        }
    }
}
