import java.util.Scanner;
import java.util.ArrayList;

public class Askhsh1 
{  

    public static void main(String[] args) 
    {
        Scanner input = new Scanner(System.in);
        ArrayList<String> Accounts = new ArrayList<>();
        ArrayList<TollDevice> tollDevices = new ArrayList<>();

        while (true) 
        {
            System.out.println("Welcome!\nDo you want to create an account to have access in a Toll device? (Please type yes or no):");
            String choice = input.nextLine();

            if (choice.equalsIgnoreCase("yes")) 
            {
                System.out.println("Fill the name of your account: ");
                String name = input.nextLine();

                System.out.println("Please confirm the name: ");
                String name1 = input.nextLine();

                if (name.equals(name1)) 
                {
                    System.out.println("Name confirmed successfully!");
                    TollDevice tollDevice = new TollDevice(name);
                    Accounts.add(name);
                    tollDevices.add(tollDevice);

                    System.out.println("Do you want to add money? (yes or no)");
                    String choice1 = input.nextLine();

                    if (choice1.equalsIgnoreCase("yes")) 
                    {
                        System.out.println("Give the amount of the money: ");
                        int cash = input.nextInt();
                        input.nextLine();

                        if (tollDevice.AddMoney(cash)) 
                        {
                            System.out.println("Money added successfully!");
                            System.out.println("Your balance is now: " + tollDevice.getMoney());
                        }
                         else 
                        {
                            System.out.println("Failed to add money. Please enter a positive amount.");
                        }
                    }

                    System.out.println("Do you want to pay the toll? (yes or no)");
                    String choice2 = input.nextLine();
                    if (choice2.equalsIgnoreCase("yes")) 
                    {
                        System.out.println("How much does the toll cost?");
                        int cost = input.nextInt();
                        input.nextLine();
                        if (tollDevice.PayToll(cost)) 
                        {
                            System.out.println("The payment was successful!");
                        } 
                        else 
                        {
                            System.out.println("Not enough balance.");
                        }
                    }
                } 
                else
                {
                    System.out.println("Names do not match. Please try again.");
                }
            } 
            else if (choice.equalsIgnoreCase("no")) 
            {
                System.out.println("You chose not to create an account.");
            }

            System.out.println("Do you want to exit from the application? (Please type yes or no):");
            String exitChoice = input.nextLine();

            if (exitChoice.equalsIgnoreCase("yes")) 
            {
                System.out.println("\nUser Balances:");
                for (int i=0;i<Accounts.size();i++) 
                {
                    TollDevice userDevice = tollDevices.get(i);
                    int balance=userDevice.getMoney();
                    System.out.println("User: " +Accounts.get(i) + ", Balance: " +balance);
                }
                break;
            }
        }

        input.close();
    }
}